# Комплект native validation

Цель: FreePCB2 2.428, Схематор 1.429, единицы MM. Скопируйте ВЕСЬ каталог.
Файлы FPL/CDS — CP1251, JSON/Markdown/SCAD — UTF-8. Установленный Python 3.10+
нужен только checker; он использует стандартную библиотеку и работает без repo.

1. Выполните `py -3 -B verify_kit.py` (macOS/Linux: `python3 -B verify_kit.py`).
   Это проверка целостности, а не подтверждение GUI, netlist, Gerber или 3D.
2. В FreePCB2 выберите MM и Папка для OpenSCAD = полный локальный путь
   `<kit>/openscad_models/Bundle.3dshapes`. Эта общая папка содержит aliases
   всех bundles. Внутренние README bundles описывают также их отдельные папки.
3. Используйте bundles/<stage>/components/<id>/{symbol.cds,footprint.fpl} и
   footprints/<id>/footprint.fpl. Полный список и expected pin/shape records
   находятся в expected-catalog.json. Planned 2D controls не получают STL по догадке.
   Catalog использует NM: 1mm=1000000NM. pin.x/y — native coordinates, angle —
   native clockwise degrees. Pad record = [shape,height,left,right,radius],
   полная ширина=left+right. Shape 0=none, 1=round, 3=rect, 4=roundrect,
   5=oval, 99=project default; inner_pad имеет дополнительный connect_flag.
4. Создайте протокол: `py -3 -B verify_kit.py --init-results results/run.json`.
   Заполните operator/versions и checks из protocol.json. Все проверки изначально
   not_run. passed требует notes и evidence: [{"path":"results/...","sha256":"..."}].
   SHA256 файла: `(Get-FileHash results/file -Algorithm SHA256).Hash.ToLower()`.
   Сохранённые native файлы, screenshots и Gerber кладите только в results/;
   используйте ASCII-имена файлов без пробелов для переносимости на Windows.
5. Проверьте протокол: `py -3 -B verify_kit.py --results results/run.json`.
   Checker подтверждает структуру/хеши evidence и kit identity; действия оператора
   и содержание screenshot криптографически не удостоверяет. Immutable manifest
   сохраняет native validation flags=false; не редактируйте его для записи успеха.
6. Файлы scenes/*.scad — library-local model previews из явных transforms.
   Опционально `py -3 -B verify_kit.py --compile-openscad C:/path/openscad.exe`.
   Это CSG syntax compilation, без remesh STL, GUI или physical frame claims.
   После relocation компилируйте заново с новым --run-id; результаты CSG могут
   содержать абсолютные пути времени запуска. Не подменяйте ими native board SCAD.

Refusals содержит source/report для ожидаемых slots/offset/nonrectangular pads;
FPL для них отсутствует. Они не заменены кругами/прямоугольниками. Source snapshots
в source/ сохраняют структуру проекта и выбранные исходники с LICENSE/provenance.
Provenance/README библиотек могут описывать больше файлов, чем выбранный snapshot.
STL скопированы побайтно только из существующего store; их source frame/license
provenance не восстанавливается из имени. hashes доказывают identity, не alignment.
ready_for_3d_checks=false означает неполный набор моделей; 3D checks тогда blocked.

Не изменяйте bundles/source/footprints/openscad_models/scenes. Для native save/export
используйте results/. Полный перечень сценариев, pass criteria и evidence — protocol.json.
