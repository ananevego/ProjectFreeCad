[options]

version: 1.429
file_version: 1.429
project_name: "symbol.cds"
units: MM
default_font: 2
default_node_width: -1000000
visible_grid_spacing: 2540000
polyline_grid_spacing: 254000
text_grid_spacing: 254000

[graphics]

rename_page: "KiCad symbols"

n_pins: 6
rectangle: -5232400 -7772400 1422400 7772400
ref_des: "P1" 0 8890000 7 0 1270000 127000 -1 -1 2 1
footprint_name: "fp_Connector_PinHeader_2.54mm_PinHeader_1x06_P2.54mm_Vertical_102db76fad6e653e" 0 0 12 0 0 0 -1 -1 2 1
part_value: "CONN_01X06" 2540000 0 13 270 1270000 127000 -1 -1 2 1
outline: 4 0 6 254000 -1 -1 -1 0
  corner: 1 -1270000 -6223000 0 0
  corner: 2 254000 -6223000 0 0
  corner: 3 254000 -6477000 0 0
  corner: 4 -1270000 -6477000 0 0

outline: 4 0 6 254000 -1 -1 -1 0
  corner: 1 -1270000 -3683000 0 0
  corner: 2 254000 -3683000 0 0
  corner: 3 254000 -3937000 0 0
  corner: 4 -1270000 -3937000 0 0

outline: 4 0 6 254000 -1 -1 -1 0
  corner: 1 -1270000 -1143000 0 0
  corner: 2 254000 -1143000 0 0
  corner: 3 254000 -1397000 0 0
  corner: 4 -1270000 -1397000 0 0

outline: 4 0 6 254000 -1 -1 -1 0
  corner: 1 -1270000 1397000 0 0
  corner: 2 254000 1397000 0 0
  corner: 3 254000 1143000 0 0
  corner: 4 -1270000 1143000 0 0

outline: 4 0 6 254000 -1 -1 -1 0
  corner: 1 -1270000 3937000 0 0
  corner: 2 254000 3937000 0 0
  corner: 3 254000 3683000 0 0
  corner: 4 -1270000 3683000 0 0

outline: 4 0 6 254000 -1 -1 -1 0
  corner: 1 -1270000 6477000 0 0
  corner: 2 254000 6477000 0 0
  corner: 3 254000 6223000 0 0
  corner: 4 -1270000 6223000 0 0

outline: 4 0 6 254000 -1 -1 -1 0
  corner: 1 -1270000 7620000 0 0
  corner: 2 1270000 7620000 0 0
  corner: 3 1270000 -7620000 0 0
  corner: 4 -1270000 -7620000 0 0

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 -1270000 6350000 0 0
  corner: 2 -5080000 6350000 0 1
pin_name: "1" -3175000 6985000 9 0 1270000 127000 -1 -1 2 1

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 -1270000 3810000 0 0
  corner: 2 -5080000 3810000 0 1
pin_name: "2" -3175000 4445000 9 0 1270000 127000 -1 -1 2 1

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 -1270000 1270000 0 0
  corner: 2 -5080000 1270000 0 1
pin_name: "3" -3175000 1905000 9 0 1270000 127000 -1 -1 2 1

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 -1270000 -1270000 0 0
  corner: 2 -5080000 -1270000 0 1
pin_name: "4" -3175000 -635000 9 0 1270000 127000 -1 -1 2 1

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 -1270000 -3810000 0 0
  corner: 2 -5080000 -3810000 0 1
pin_name: "5" -3175000 -3175000 9 0 1270000 127000 -1 -1 2 1

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 -1270000 -6350000 0 0
  corner: 2 -5080000 -6350000 0 1
pin_name: "6" -3175000 -5715000 9 0 1270000 127000 -1 -1 2 1

part_end

[end]
