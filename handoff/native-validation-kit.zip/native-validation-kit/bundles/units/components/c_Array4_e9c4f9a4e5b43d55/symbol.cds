[options]

version: 1.429
file_version: 1.429
project_name: "symbol.cds"
units: MM
default_font: 2
default_node_width: -1000000
visible_grid_spacing: 2540000
polyline_grid_spacing: 254000
text_grid_spacing: 254000

[graphics]

rename_page: "KiCad symbols"

n_pins: 8
rectangle: -1168400 -3962400 15798800 3962400
ref_des: "RN2" 2032000 0 7 270 1270000 127000 -1 -1 2 1
footprint_name: "fp_Resistor_SMD_R_Array_Concave_4x0603_e417d5948ae7fceb" 0 0 12 0 0 0 -1 -1 2 1
part_value: "R_Pack04_Split" 0 0 13 270 1270000 127000 -1 -1 2 1
outline: 4 0 6 254000 -1 -1 -1 0
  corner: 1 1016000 2540000 0 0
  corner: 2 -1016000 2540000 0 0
  corner: 3 -1016000 -2540000 0 0
  corner: 4 1016000 -2540000 0 0

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 0 2540000 0 0
  corner: 2 0 3810000 0 1
pin_name: "8" 635000 3175000 9 0 1270000 127000 -1 -1 2 1

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 0 -2540000 0 0
  corner: 2 0 -3810000 0 1
pin_name: "1" -635000 -3175000 9 0 1270000 127000 -1 -1 2 1

outline: 4 0 6 254000 -1 -1 -1 0
  corner: 1 5892800 2540000 0 0
  corner: 2 3860800 2540000 0 0
  corner: 3 3860800 -2540000 0 0
  corner: 4 5892800 -2540000 0 0

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 4876800 2540000 0 0
  corner: 2 4876800 3810000 0 1
pin_name: "7" 5511800 3175000 9 0 1270000 127000 -1 -1 2 1

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 4876800 -2540000 0 0
  corner: 2 4876800 -3810000 0 1
pin_name: "2" 4241800 -3175000 9 0 1270000 127000 -1 -1 2 1

outline: 4 0 6 254000 -1 -1 -1 0
  corner: 1 10769600 2540000 0 0
  corner: 2 8737600 2540000 0 0
  corner: 3 8737600 -2540000 0 0
  corner: 4 10769600 -2540000 0 0

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 9753600 2540000 0 0
  corner: 2 9753600 3810000 0 1
pin_name: "6" 10388600 3175000 9 0 1270000 127000 -1 -1 2 1

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 9753600 -2540000 0 0
  corner: 2 9753600 -3810000 0 1
pin_name: "3" 9118600 -3175000 9 0 1270000 127000 -1 -1 2 1

outline: 4 0 6 254000 -1 -1 -1 0
  corner: 1 15646400 2540000 0 0
  corner: 2 13614400 2540000 0 0
  corner: 3 13614400 -2540000 0 0
  corner: 4 15646400 -2540000 0 0

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 14630400 2540000 0 0
  corner: 2 14630400 3810000 0 1
pin_name: "5" 15265400 3175000 9 0 1270000 127000 -1 -1 2 1

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 14630400 -2540000 0 0
  corner: 2 14630400 -3810000 0 1
pin_name: "4" 13995400 -3175000 9 0 1270000 127000 -1 -1 2 1

part_end

[end]
