KiCad -> FreePCB2 / Schemator component bundle

Each generated component has symbol.cds, footprint.fpl and report.json.
Native imports, netlist, fonts and 3D alignment are NOT GUI-validated.
Copy the WHOLE directory. Paths in manifest.json are relative to it.
Import the FPL libraries in FreePCB2 2.428 and CDS libraries in Schemator 1.429.
Use project units MM; set the FreePCB2 OpenSCAD folder to:
  <bundle>/openscad_models/Bundle.3dshapes
Do not select the category tree models/: FPL imports use unique flat aliases.
The category tree preserves original paths; both copies have the same SHA256.
Only selected existing STL bytes were copied; meshes were not converted or inspected.
Verify after copying with: python3 -B -m src.component_converter --verify <bundle>
