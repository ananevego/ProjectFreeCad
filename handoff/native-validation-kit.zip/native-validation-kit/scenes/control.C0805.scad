// Library-local preview only; board frame/alignment unverified.
translate([0,0,0]) rotate([0,0,0]) scale([1,1,1])
import("../openscad_models/Bundle.3dshapes/mdl_Capacitor_SMD.3dshapes_C_0805_2012Metric_54dc537275d6d7ea.stl");
