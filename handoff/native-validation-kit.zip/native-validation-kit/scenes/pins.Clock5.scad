// Library-local preview only; board frame/alignment unverified.
translate([0,0,0]) rotate([0,0,0]) scale([1,1,1])
import("../openscad_models/Bundle.3dshapes/mdl_Package_TO_SOT_SMD.3dshapes_SOT-23-5_bc14922ffd39e0ca.stl");
