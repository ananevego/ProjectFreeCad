// Library-local preview only; board frame/alignment unverified.
translate([0,0,0]) rotate([0,0,0]) scale([1,1,1])
import("../openscad_models/Bundle.3dshapes/mdl_Resistor_SMD.3dshapes_R_0805_2012Metric_32579fcf66304c54.stl");
