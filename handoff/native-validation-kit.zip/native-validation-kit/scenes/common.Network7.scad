// Library-local preview only; board frame/alignment unverified.
translate([0,0,0]) rotate([0,0,0]) scale([1,1,1])
import("../openscad_models/Bundle.3dshapes/mdl_Resistor_THT.3dshapes_R_Array_SIP8_86a2c26a027a203d.stl");
