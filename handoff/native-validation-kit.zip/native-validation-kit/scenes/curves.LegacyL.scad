// Library-local preview only; board frame/alignment unverified.
translate([0,0,0]) rotate([0,0,0]) scale([1,1,1])
import("../openscad_models/Bundle.3dshapes/mdl_Inductor_SMD.3dshapes_L_0805_2012Metric_0365923e5f028bd6.stl");
