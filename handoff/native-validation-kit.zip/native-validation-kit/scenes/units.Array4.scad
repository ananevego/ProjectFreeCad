// Library-local preview only; board frame/alignment unverified.
translate([0,0,0]) rotate([0,0,0]) scale([1,1,1])
import("../openscad_models/Bundle.3dshapes/mdl_Resistor_SMD.3dshapes_R_Array_Concave_4x0603_df14394c4d8df713.stl");
