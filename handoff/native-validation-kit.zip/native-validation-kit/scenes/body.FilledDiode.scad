// Library-local preview only; board frame/alignment unverified.
translate([0,0,0]) rotate([0,0,0]) scale([1,1,1])
import("../openscad_models/Bundle.3dshapes/mdl_Diode_SMD.3dshapes_D_SOD-123_ab0ed97943d7ea32.stl");
