// Library-local preview only; board frame/alignment unverified.
translate([0,0,0]) rotate([0,0,0]) scale([1,1,1])
import("../openscad_models/Bundle.3dshapes/mdl_Package_DIP.3dshapes_DIP-8_W7.62mm_31cca7f26b74f516.stl");
