// Library-local preview only; board frame/alignment unverified.
translate([0,0,0]) rotate([0,0,0]) scale([1,1,1])
import("../openscad_models/Bundle.3dshapes/mdl_Connector_PinHeader_2.54mm.3dshapes_PinHeader_1x02_P2.54mm_V_4a64ae3a15a847fe.stl");
