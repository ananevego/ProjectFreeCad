// Library-local preview only; board frame/alignment unverified.
translate([0,0,0]) rotate([0,0,0]) scale([1,1,1])
import("../openscad_models/Bundle.3dshapes/mdl_Resistor_THT.3dshapes_R_Array_SIP5_1ce3e53d2d1ca96e.stl");
