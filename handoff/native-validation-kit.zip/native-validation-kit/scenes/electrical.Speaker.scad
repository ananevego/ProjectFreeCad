// Library-local preview only; board frame/alignment unverified.
translate([0,0,0]) rotate([0,0,0]) scale([1,1,1])
import("../openscad_models/Bundle.3dshapes/mdl_Buzzer_Beeper.3dshapes_Speaker_CUI_CMR-1206S-67_590bd328f29c6a0b.stl");
