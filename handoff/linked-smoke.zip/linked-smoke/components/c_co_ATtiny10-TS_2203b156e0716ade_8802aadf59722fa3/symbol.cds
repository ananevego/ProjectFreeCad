[options]

version: 1.429
file_version: 1.429
project_name: "symbol.cds"
units: MM
default_font: 2
default_node_width: -1000000
visible_grid_spacing: 2540000
polyline_grid_spacing: 254000
text_grid_spacing: 254000

[graphics]

rename_page: "KiCad symbols"

n_pins: 6
rectangle: -12852400 -15392400 15392400 15392400
ref_des: "U1" -12700000 13970000 7 0 1270000 127000 -1 -1 2 1
footprint_name: "fp_Package_TO_SOT_SMD_SOT-23-6_20be62bda182f945" 0 0 12 0 0 0 -1 -1 2 1
part_value: "ATtiny10-TS" 2540000 -13970000 13 0 1270000 127000 -1 -1 2 1
outline: 4 0 6 254000 -1 -1 -1 0
  corner: 1 -12700000 -12700000 0 0
  corner: 2 12700000 -12700000 0 0
  corner: 3 12700000 12700000 0 0
  corner: 4 -12700000 12700000 0 0

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 0 12700000 0 0
  corner: 2 0 15240000 0 1
pin_name: "5" 635000 13970000 9 0 1270000 127000 -1 -1 2 1
description: "VCC" 0 12192000 14 0 1270000 127000 -1 -1 2 1

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 0 -12700000 0 0
  corner: 2 0 -15240000 0 1
pin_name: "2" -635000 -13970000 9 0 1270000 127000 -1 -1 2 1
description: "GND" 0 -12192000 14 0 1270000 127000 -1 -1 2 1

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 12700000 7620000 0 0
  corner: 2 15240000 7620000 0 1
pin_name: "1" 13970000 6985000 9 0 1270000 127000 -1 -1 2 1
description: "PB0" 12192000 7620000 14 0 1270000 127000 -1 -1 2 1

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 12700000 5080000 0 0
  corner: 2 15240000 5080000 0 1
pin_name: "3" 13970000 4445000 9 0 1270000 127000 -1 -1 2 1
description: "PB1" 12192000 5080000 14 0 1270000 127000 -1 -1 2 1

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 12700000 2540000 0 0
  corner: 2 15240000 2540000 0 1
pin_name: "4" 13970000 1905000 9 0 1270000 127000 -1 -1 2 1
description: "PB2" 12192000 2540000 14 0 1270000 127000 -1 -1 2 1

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 12700000 0 0 0
  corner: 2 15240000 0 0 1
pin_name: "6" 13970000 -635000 9 0 1270000 127000 -1 -1 2 1
description: "RESET/PB3" 12192000 0 14 0 1270000 127000 -1 -1 2 1

part_end

[end]
