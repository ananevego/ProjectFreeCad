[options]

version: 1.429
file_version: 1.429
project_name: "symbol.cds"
units: MM
default_font: 2
default_node_width: -1000000
visible_grid_spacing: 2540000
polyline_grid_spacing: 254000
text_grid_spacing: 254000

[graphics]

rename_page: "KiCad symbols"

n_pins: 5
rectangle: -10312400 -10312400 10312400 10312400
ref_des: "U1" -3810000 6350000 7 0 1270000 127000 -1 -1 2 1
footprint_name: "fp_Package_TO_SOT_SMD_SOT-353_SC-70-5_be0514ca09a40ca5" 0 0 12 0 0 0 -1 -1 2 1
part_value: "74AHC1G4210" 7620000 6350000 13 0 1270000 127000 -1 -1 2 1
outline: 4 0 6 254000 -1 -1 -1 0
  corner: 1 -5080000 5080000 0 0
  corner: 2 5080000 5080000 0 0
  corner: 3 5080000 -5080000 0 0
  corner: 4 -5080000 -5080000 0 0

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 -5080000 2540000 0 0
  corner: 2 -10160000 2540000 0 1
pin_name: "1" -7620000 3175000 9 0 1270000 127000 -1 -1 2 1
description: "X1" -4572000 2540000 14 0 1270000 127000 -1 -1 2 1

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 -5080000 -2540000 0 0
  corner: 2 -10160000 -2540000 0 1
pin_name: "2" -7620000 -1905000 9 0 1270000 127000 -1 -1 2 1
description: "X2" -4572000 -2540000 14 0 1270000 127000 -1 -1 2 1

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 0 5080000 0 0
  corner: 2 0 10160000 0 1
pin_name: "5" 635000 7620000 9 0 1270000 127000 -1 -1 2 1
description: "VCC" 0 4572000 14 0 1270000 127000 -1 -1 2 1

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 0 -5080000 0 0
  corner: 2 0 -10160000 0 1
pin_name: "3" -635000 -7620000 9 0 1270000 127000 -1 -1 2 1
description: "GND" 0 -4572000 14 0 1270000 127000 -1 -1 2 1

polyline: 2 0 8 254000 -1 -1 -1 0
  corner: 1 5080000 0 0 0
  corner: 2 10160000 0 0 1
pin_name: "4" 7620000 -635000 9 0 1270000 127000 -1 -1 2 1
description: "Q" 4572000 0 14 0 1270000 127000 -1 -1 2 1

part_end

[end]
