from pathlib import Path
import hashlib, json, sys
root=Path(__file__).resolve().parent
try:
 m=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
 expected={'manifest.json'}|{e['path'] for e in m['files']}
 actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
 if actual!=expected: raise ValueError('File set differs from manifest')
 for e in m['files']:
  data=(root/e['path']).read_bytes()
  if len(data)!=e['bytes'] or hashlib.sha256(data).hexdigest()!=e['sha256']:
   raise ValueError('File changed: '+e['path'])
 print('Linked smoke sample verified:',len(m['components']),'components,',len(m['files']),'files')
except (OSError,ValueError,KeyError) as error:
 print('Verification failed:',error,file=sys.stderr); raise SystemExit(1)
