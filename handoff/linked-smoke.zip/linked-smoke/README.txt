Linked Windows smoke sample from the audited 8,210-component preview.

Open each components/*/symbol.cds in Schemator 1.429 and footprint.fpl in
FreePCB2 2.428. Use MM and point FreePCB2 OpenSCAD folder to the absolute
path <this package>/openscad_models/Bundle.3dshapes. The three samples are
74AHC1G4210 (SOT-353), NE555P (DIP-8), and ATtiny10-TS (SOT-23-6).
Their report.json files state all known conversion losses.

Run `py -3 -B verify.py` from this folder before native checks.
This sample does not replace the full linked preview or prove all 8,210
components work in the GUI. Save native results in the other kit's results/.
